@echo off
setlocal EnableExtensions

net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo Requesting administrator permission...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

set "PLUGIN_SRC=%~dp0PSD Auto Slicer"
set "DEFAULT_PS=C:\Program Files\Adobe\Adobe Photoshop 2022"
set "PS_DIR=%DEFAULT_PS%"

if not exist "%PS_DIR%\Photoshop.exe" (
  echo Could not find Photoshop 2022 at:
  echo   %DEFAULT_PS%
  echo.
  set /p "PS_DIR=Paste your Adobe Photoshop 2022 install folder path: "
)

if not exist "%PS_DIR%\Photoshop.exe" (
  echo.
  echo Photoshop.exe was not found in:
  echo   %PS_DIR%
  echo Installation cancelled.
  pause
  exit /b 1
)

set "TARGET_DIR=%PS_DIR%\Plug-ins\PSD Auto Slicer"

echo.
echo Installing PSD Auto Slicer to:
echo   %TARGET_DIR%
echo.

if not exist "%PS_DIR%\Plug-ins" mkdir "%PS_DIR%\Plug-ins"
if exist "%TARGET_DIR%" rmdir /s /q "%TARGET_DIR%"
robocopy "%PLUGIN_SRC%" "%TARGET_DIR%" /E /NFL /NDL /NJH /NJS /NP >nul

if errorlevel 8 (
  echo Installation failed while copying files.
  pause
  exit /b 1
)

echo Installation complete.
echo Restart Photoshop 2022, then open Plugins ^> PSD Auto Slicer.
pause
