PSD Auto Slicer v0.2.48 - Photoshop 2022 manual install

This package is for Windows users who do not have Creative Cloud Desktop available to install a .ccx package.

Compatibility:
- Target: Adobe Photoshop 2022 23.3 or newer.
- If your Photoshop 2022 is older than 23.3, update Photoshop 2022 first. This UXP package uses manifest v5.

Install:
1. Close Photoshop.
2. Right click install_to_photoshop_2022_plugins.bat.
3. Choose Run as administrator.
4. If Photoshop 2022 is not installed at C:\Program Files\Adobe\Adobe Photoshop 2022, paste your Photoshop 2022 install folder when prompted.
5. Restart Photoshop.
6. Open Plugins > PSD Auto Slicer.

Manual install without the bat:
Copy the folder named "PSD Auto Slicer" into:
C:\Program Files\Adobe\Adobe Photoshop 2022\Plug-ins\

Final path should be:
C:\Program Files\Adobe\Adobe Photoshop 2022\Plug-ins\PSD Auto Slicer\manifest.json
